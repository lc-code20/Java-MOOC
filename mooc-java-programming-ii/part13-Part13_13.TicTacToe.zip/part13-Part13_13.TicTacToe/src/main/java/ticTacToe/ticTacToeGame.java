/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ticTacToe;

import java.util.ArrayList;

/**
 *
 * @author lwych
 */
public class ticTacToeGame {
    int count;
    MagicSquare game;
    String sign;
    
    public ticTacToeGame(){
        this.count = 0;
        this.game = new MagicSquare(3);
        this.sign = "X";
    }
    
    public String assignSign(){
        count++;
        //System.out.println("count is " + count);
 
        if (count%2 == 1){
            this.sign = "X";
        }
        
        if (count%2 == 0){
            this.sign = "O";
        }
        
        //System.out.println("this sign is "+ this.sign);
        return this.sign;
    }
    
    public String getCurrentSign(){
        return this.sign;
    }
    
    public String getTurn(){
        if (this.sign.equals("O")){
            return "X";
        } else if (this.sign.equals("X")){
            return "O";
        }
        
        return "not assigned";
    }
    
    public Boolean gameEnded(){
        if (count == 9){
            return true;
        }
        
        if (checkGame(3)){;
            return true;
        }
        
        if(checkGame(12)){
            return true;
        }
        
        return false;
    }
    
    public void placeValue(int x, int y, int value){
        this.game.placeValue(x, y, value);
    }
    
    public int readValue(int x, int y){
        return this.game.readValue(x,y);
    }
    
    public MagicSquare getGame(){
        return this.game;
    }
    
    public Boolean checkGame(int i){

        if (this.game.sumsOfRows().contains(i)){
            return true;
        }
         
        if (this.game.sumsOfColumns().contains(i)){
            return true;
        }
           
        if (this.game.sumsOfDiagonals().contains(i)){
            return true;
        }
        
        return false;
    }
    
    public void printGame(){
        System.out.println(this.game);
    }
  
    
}
