package ticTacToe;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class TicTacToeApplication extends Application{
    
    private ticTacToeGame game;
   
    @Override
    public void init() throws Exception {
        // Create game
        this.game = new ticTacToeGame();

    }
    
    @Override
    public void start (Stage stage) throws Exception{

        BorderPane layout = new BorderPane();
        
        Label gameMessage = new Label("Turn: X");
        
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10, 10, 10, 10));
        
        
        for (int i = 0; i < 3; i++){
            for (int j = 0; j < 3; j++){
                Button b = new Button(" ");
                b.setFont(Font.font("Monospaced", 40));
                grid.add(b, i, j);
                
                int helperI = i;
                int helperJ = j;
                
                b.setOnAction((event)->{ 
                    String s = game.assignSign();
                    b.setText(s);
                    game.placeValue(helperI, helperJ, buttonAssign());
                    gameMessage.setText("Turn : " + game.getTurn());
                    
                    printGameEnd(gameMessage);
                    b.setDisable(true);
                    
                }); 
            } 
        }
        
        // Format layer
        layout.setPadding(new Insets(20, 20, 20, 20));
        
        
        // Set gameMessage at the top
        layout.setTop(gameMessage);
           
        
        // Set grid in center
        layout.setCenter(grid);


        // Create main scene with layout 
        Scene scene = new Scene(layout);


        // Show the main scene
        stage.setScene(scene);
        stage.show();
    
    }

    // Assigns value for each X, O and returns int value for calculation of winning
    private int buttonAssign(){
        int valueOfChoice = 0;
        
        if (game.getCurrentSign().equals("X")){
                    valueOfChoice = 1;
        } else if (game.getCurrentSign().equals("O")){
                    valueOfChoice = 4;
        }
       
        return valueOfChoice;
    }
    
    // Last gameMessage when the game ends
    private void printGameEnd(Label gM){
        if(game.gameEnded()){
            gM.setText("The end!");
            //Platform.exit();
        }
    }
    
    // Create Buttons
    private Button createButton(){
        Button b = new Button(" ");
        b.setFont(Font.font("Monospaced", 40));
        return b;
    }
   
    public static void main(String[] args) {
        System.out.println("Hello world!");
        launch(TicTacToeApplication.class);
    }

}
